# 🎬 Movie Recommender System

## Description
A simple genre-based movie recommender using content-based filtering and Streamlit.

## How to Run
1. Install Python and required packages:
```bash
pip install streamlit pandas scikit-learn
```

2. Run the app:
```bash
streamlit run app.py
```

3. Type a genre like "Action", "Comedy", etc. and get top 5 movie recommendations!

## Dataset
Dataset used is a sample from [MovieLens](https://grouplens.org/datasets/movielens/).
